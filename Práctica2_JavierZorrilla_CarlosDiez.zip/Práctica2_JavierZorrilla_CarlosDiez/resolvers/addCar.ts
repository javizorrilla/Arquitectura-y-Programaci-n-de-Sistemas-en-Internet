import { RouterContext } from "https://deno.land/x/oak@v11.1.0/router.ts";
import { CarSchema } from "../db/schemas.ts";
import { Car } from "../types.ts";
import { carsAll } from "../db/mongo.ts";

type PostCarsContext = RouterContext<
  "/cars",
  Record<string | number, string | undefined>,
  Record<string, any>
>;

type GetCarContext = RouterContext<
  "/addCar",
  Record<string | number, string | undefined>,
  Record<string, any>
>;

export const postCars = async (context: GetCarContext) => {
  const result = context.request.body({ type: "json" });
  const value = await result.value;
  if (!value?.id) {
    context.response.status = 404;
    return;
  } else if (!value?.status === true) {
    context.response.status = 400;
    return;
  } else if (!value?.status === false) {
    value.status = true;
    context.response.status = 200;
    return;
  }
  const car: Partial<Car> = {
    matricula: value.matricula,
    numeroPlazas: value.numeroPlazas,
    status: value.status
  };
  const id = await carsAll.insertOne(car as CarSchema);
  car.id = id.toString();
  context.response.body = {
    id: value.id,
    matricula: value.matricula,
    numeroPlazas: value.numeroPlazas,
    status: value.status
  };
};