import { Database, ObjectId } from "https://deno.land/x/mongo@v0.31.1/mod.ts";
import { getQuery } from "https://deno.land/x/oak@v11.1.0/helpers.ts";
import { RouterContext } from "https://deno.land/x/oak@v11.1.0/router.ts";
import { carsAll } from "../db/mongo.ts";
import { CarSchema } from "../db/schemas.ts";

type GetCarsContext = RouterContext<
  "/cars",
  Record<string | number, string | undefined>,
  Record<string, any>
>;

type GetCarContext = RouterContext<
  "/car/:id",
  {
    id:string;
  }
  & Record<string | number, string | undefined>,
  Record<string, any>
>;

export const getCars = async (context: GetCarsContext) => {
const cars = await carsAll.find({}).toArray();
  context.response.body = cars.map((car) => ({
    id: car._id.toString(),
    matricula: car.matricula,
    numeroPlazas: car.numeroPlazas,
  }));
};

export const getCar = async (context: GetCarContext) => {
  if (context.params?.id) {
    const car: CarSchema | undefined = await carsAll.findOne({
      _id: new ObjectId(context.params.id),
    });

    if (car) {
      context.response.body = car;
      return;
    }
  }

  context.response.status = 404;
};

