import { Database, ObjectId } from "https://deno.land/x/mongo@v0.31.1/mod.ts";
import { getQuery } from "https://deno.land/x/oak@v11.1.0/helpers.ts";
import { RouterContext } from "https://deno.land/x/oak@v11.1.0/router.ts";
import { carsAll } from "../db/mongo.ts";
import { CarSchema } from "../db/schemas.ts";

type GetCarsContext = RouterContext<
  "/cars",
  Record<string | number, string | undefined>,
  Record<string, any>
>;

type GetCarContext = RouterContext<
  "/askCar",
  & Record<string | number, string | undefined>,
  Record<string, any>
>;

export const getCar_3 = async (context: GetCarContext) => {
  if (context.params?.id) {
    const car: CarSchema | undefined = await carsAll.findOne({
      _id: new ObjectId(context.params.id),
    });

    if (car && car.status) { // Si hay coches disponibles y están libres
      context.response.body = car;
      return;
    } else { // Sino hay coches disponibles y están ocupados
        context.response.body = "Car not found";
        context.response.status = 404;
    }
  }

  context.response.status = 404;
};