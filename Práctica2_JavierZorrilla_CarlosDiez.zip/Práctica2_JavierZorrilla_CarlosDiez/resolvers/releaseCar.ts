import { Database, ObjectId } from "https://deno.land/x/mongo@v0.31.1/mod.ts";
import { getQuery } from "https://deno.land/x/oak@v11.1.0/helpers.ts";
import { RouterContext } from "https://deno.land/x/oak@v11.1.0/router.ts";
import { carsAll } from "../db/mongo.ts";
import { CarSchema } from "../db/schemas.ts";

type GetCarsContext = RouterContext<
  "/cars",
  Record<string | number, string | undefined>,
  Record<string, any>
>;

type GetCarContext = RouterContext<
  "/releaseCar/:id",
  {
    id: string;
  } & Record<string | number, string | undefined>,
  Record<string, any>
>;

export const getCars_2 = async (context: GetCarsContext) => {
    const cars = await carsAll.find({}).toArray();
    context.response.body = cars.map((car) => ({
      id: car._id.toString(),
      matricula: car.matricula,
      numeroPlazas: car.numeroPlazas,
      status: car.status
    }));
    return;
  }


export const getCar_2 = async (context: GetCarContext) => {
  if (context.params?.id) {
    const car: CarSchema | undefined = await carsAll.findOne({
      _id: new ObjectId(context.params.id),
    });

    if (car) {
      if(car.status) {
        context.response.status = 400;
        context.response.body = car;
        return;
      } else {
        car.status = true;
        context.response.status = 200;
        context.response.body = car;
        return;
      }
    } else {
      context.response.status = 404;
      return;
    }
  }

  //context.response.status = 404;
};