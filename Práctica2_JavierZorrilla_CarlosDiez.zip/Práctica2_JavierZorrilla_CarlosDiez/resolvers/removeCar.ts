import { RouterContext } from "https://deno.land/x/oak@v11.1.0/router.ts";
import { ObjectId } from "https://deno.land/x/mongo@v0.31.1/mod.ts";
import { carsAll } from "../db/mongo.ts";

type DeleteCarContext = RouterContext<
  "/removeCar/:id",
  {
    id: string;
  } & Record<string | number, string | undefined>,
  Record<string, any>
>;

export const deleteCar = async (context: DeleteCarContext) => {
  if (context.params?.id) {
    const count = await carsAll.deleteOne({
      _id: new ObjectId(context.params.id),
    });

    if (count) {
        if(context.params?.status) {
            context.response.status = 200;
            return;
        } else {
            context.response.status = 405;
            return;
        }
    } else {
      context.response.status = 404;
    }
  }
};