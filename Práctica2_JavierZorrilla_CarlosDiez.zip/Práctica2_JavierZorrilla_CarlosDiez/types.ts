export type Car = {
    id: string;
    matricula: string;
    numeroPlazas: number;
    status: boolean;
}