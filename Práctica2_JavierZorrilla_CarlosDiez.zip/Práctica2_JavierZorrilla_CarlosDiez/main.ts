import { Application, Router } from "https://deno.land/x/oak@v11.1.0/mod.ts";

/*import { getCar, getCars } from "./resolvers/askcar.ts";
import { postCars } from "./resolvers/addCar.ts";
import { deleteBook } from "./resolvers/delete.ts";
import { putBook } from "./resolvers/put.ts";*/

import { getCar } from "./resolvers/carsID.ts";
import { postCars } from "./resolvers/addCar.ts";
import { deleteCar } from "./resolvers/removeCar.ts";
import { getCar_2 } from "./resolvers/releaseCar.ts";
import { getCar_3 } from "./resolvers/askCar.ts";


const router = new Router();

router
  .post("/addCar", postCars)
  .delete("/removeCar/:id", deleteCar)
  .get("/car/:id", getCar)
  .get("/askCar", getCar_3)
  .get("/releaseCar/:id", getCar_2);

const app = new Application();

app.use(router.routes());
app.use(router.allowedMethods());

await app.listen({ port: 7777 });