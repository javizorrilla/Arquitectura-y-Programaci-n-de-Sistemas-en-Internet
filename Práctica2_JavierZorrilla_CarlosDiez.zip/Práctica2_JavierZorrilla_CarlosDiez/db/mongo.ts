import {
    MongoClient, 
    Database, 
} from "https://deno.land/x/mongo@v0.31.1/mod.ts";

import { CarSchema } from "./schemas.ts";

const connectMongoDB = async (): Promise<Database> => {
    const client = new MongoClient();
    await client.connect("mongodb+srv://javi_zorrilla:Martaynuria20@cluster0.ytel0oc.mongodb.net/?authMechanism=SCRAM-SHA-1");
    const db = client.database("carstore");

    return db;
}

const db = await connectMongoDB();

export const carsAll = db.collection<CarSchema>("Cars");

